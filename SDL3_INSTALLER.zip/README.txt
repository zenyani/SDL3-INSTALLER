HI!	
this sdl installer easy install you SDL3
creator:Zenyani