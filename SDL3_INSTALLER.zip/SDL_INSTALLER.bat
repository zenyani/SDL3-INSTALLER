@echo off
setlocal
set "BASE=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0'); iex ($s.Split(@('<<'+'PS>>'),[StringSplitOptions]::None)[1])"
echo.
pause
exit /b
<<PS>>
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$H = @{ 'User-Agent' = 'sdl3-setup-script' }

function Step($t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Save($rel, $text) {
    $p = Join-Path $root $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $p) | Out-Null
    [IO.File]::WriteAllText($p, $text, (New-Object Text.UTF8Encoding $false))
}

try {
    $base = $env:BASE
    if ($base -match '[^\x00-\x7F]') {
        Write-Host "Path contains non-ASCII characters (gdb can't handle them) - using C:\ instead" -ForegroundColor Yellow
        $base = 'C:\'
    }
    $root = Join-Path $base 'SDL22'
    $tmp  = Join-Path $root '_tmp'

    Step "Creating folder $root"
    New-Item -ItemType Directory -Force -Path $root, $tmp | Out-Null

    # ---------- SDL3 ----------
    $sdl = Join-Path $root 'SDL3'
    if (Test-Path (Join-Path $sdl 'include\SDL3\SDL.h')) {
        Step "SDL3 already downloaded, skipping"
    } else {
        Step "Looking for the latest SDL3 release"
        $rels = Invoke-RestMethod 'https://api.github.com/repos/libsdl-org/SDL/releases?per_page=50' -Headers $H
        $rel = $rels | Where-Object { $_.tag_name -match '^release-3\.\d+\.\d+$' -and -not $_.prerelease } | Select-Object -First 1
        if (-not $rel) { throw "SDL3 release not found" }
        $asset = $rel.assets | Where-Object { $_.name -match '^SDL3-devel-.*-mingw\.tar\.gz$' } | Select-Object -First 1
        if (-not $asset) { throw "MinGW package not found in release $($rel.tag_name)" }
        Write-Host "Downloading $($asset.name)"
        $arc = Join-Path $tmp $asset.name
        Invoke-WebRequest $asset.browser_download_url -OutFile $arc -Headers $H
        Step "Unpacking SDL3"
        tar -xzf $arc -C $tmp
        $dir = Get-ChildItem $tmp -Directory | Where-Object { $_.Name -like 'SDL3-*' } | Select-Object -First 1
        $src = Join-Path $dir.FullName 'x86_64-w64-mingw32'
        if (-not (Test-Path $src)) { throw "x86_64-w64-mingw32 folder not found in the archive" }
        Copy-Item $src $sdl -Recurse -Force
    }

    # ---------- Compiler (g++ / gdb) ----------
    $gxx = $null; $gdb = $null; $extraPath = ''
    $sys = Get-Command g++ -ErrorAction SilentlyContinue
    $local = Join-Path $root 'toolchain\w64devkit\bin\g++.exe'
    if ($sys) {
        Step "Found g++ in PATH: $($sys.Source)"
        $gxx = $sys.Source
        $g = Get-Command gdb -ErrorAction SilentlyContinue
        if ($g) { $gdb = $g.Source }
    } elseif (Test-Path $local) {
        Step "Local compiler already installed"
        $gxx = $local
    } else {
        Step "g++ not found - downloading portable w64devkit (MinGW-w64)"
        $rels = Invoke-RestMethod 'https://api.github.com/repos/skeeto/w64devkit/releases?per_page=10' -Headers $H
        $asset = $null
        foreach ($r in $rels) {
            $asset = $r.assets | Where-Object { $_.name -match '\.7z\.exe$' -and $_.name -notmatch 'i686|fortran' } | Select-Object -First 1
            if ($asset) { break }
        }
        if (-not $asset) { throw "w64devkit package not found" }
        Write-Host "Downloading $($asset.name) (this may take a while)"
        $exe = Join-Path $tmp $asset.name
        Invoke-WebRequest $asset.browser_download_url -OutFile $exe -Headers $H
        $tc = Join-Path $root 'toolchain'
        New-Item -ItemType Directory -Force -Path $tc | Out-Null
        Start-Process -FilePath $exe -ArgumentList @('-y', "-o`"$tc`"") -Wait -NoNewWindow
        if (-not (Test-Path $local)) { throw "Compiler extraction failed" }
        $gxx = $local
    }
    if ($gxx -like "$root*") {
        $bin = Split-Path $gxx
        $extraPath = $bin
        if (Test-Path (Join-Path $bin 'gdb.exe')) { $gdb = Join-Path $bin 'gdb.exe' }
    }

    # Paths written to .vscode are portable (no user-specific absolute paths)
    if ($extraPath) {
        $gxxJ = '${workspaceFolder}/toolchain/w64devkit/bin/g++.exe'
        $gdbJ = '${workspaceFolder}/toolchain/w64devkit/bin/gdb.exe'
        $binJ = '${workspaceFolder}/toolchain/w64devkit/bin'
    } else {
        $gxxJ = 'g++'
        $gdbJ = 'gdb'
        $binJ = ''
    }

    # ---------- Project ----------
    Step "Creating project files"
    New-Item -ItemType Directory -Force -Path (Join-Path $root 'build') | Out-Null
    Copy-Item (Join-Path $sdl 'bin\SDL3.dll') (Join-Path $root 'build\SDL3.dll') -Force

    $main = @'
#include <SDL3/SDL.h>

int main(int argc, char* argv[])
{
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("SDL3 Hello", 800, 600, 0);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, nullptr);
    if (!window || !renderer) {
        SDL_Log("Window/renderer failed: %s", SDL_GetError());
        return 1;
    }

    bool running = true;
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_EVENT_QUIT) running = false;
        }

        SDL_SetRenderDrawColor(renderer, 30, 30, 60, 255);
        SDL_RenderClear(renderer);

        SDL_FRect rect{ 300.0f, 200.0f, 200.0f, 200.0f };
        SDL_SetRenderDrawColor(renderer, 255, 120, 0, 255);
        SDL_RenderFillRect(renderer, &rect);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
'@
    if (-not (Test-Path (Join-Path $root 'src\main.cpp'))) { Save 'src\main.cpp' $main }

    $tasks = @'
{
  "version": "2.0.0",
  "tasks": [
    {
      "type": "cppbuild",
      "label": "C/C++: g++.exe build active file",
      "command": "__GXX__",
      "args": [
        "-g", "-std=c++17", "-Wall",
        "${workspaceFolder}/src/main.cpp",
        "-o", "${workspaceFolder}/build/app.exe",
        "-I${workspaceFolder}/SDL3/include",
        "-L${workspaceFolder}/SDL3/lib",
        "-lSDL3"
      ],
      "options": { "cwd": "${workspaceFolder}" },
      "group": { "kind": "build", "isDefault": true },
      "problemMatcher": ["$gcc"]
    },
    {
      "label": "build",
      "dependsOn": "C/C++: g++.exe build active file",
      "problemMatcher": []
    }
  ]
}
'@
    Save '.vscode\tasks.json' ($tasks.Replace('__GXX__', $gxxJ))

    $launch = @'
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Debug SDL3",
      "type": "cppdbg",
      "request": "launch",
      "program": "${workspaceFolder}/build/app.exe",
      "args": [],
      "stopAtEntry": false,
      "cwd": "${workspaceFolder}/build",
      "environment": [],
      "externalConsole": false,
      "MIMode": "gdb",
      "miDebuggerPath": "__GDB__",
      "preLaunchTask": "build"
    }
  ]
}
'@
    Save '.vscode\launch.json' ($launch.Replace('__GDB__', $gdbJ))

    $cpp = @'
{
  "version": 4,
  "configurations": [
    {
      "name": "Win32",
      "includePath": [ "${workspaceFolder}/SDL3/include", "${workspaceFolder}/src" ],
      "compilerPath": "__GXX__",
      "cStandard": "c17",
      "cppStandard": "c++17",
      "intelliSenseMode": "windows-gcc-x64"
    }
  ]
}
'@
    Save '.vscode\c_cpp_properties.json' ($cpp.Replace('__GXX__', $gxxJ))

    if ($extraPath) {
        $set = @'
{
  "terminal.integrated.env.windows": {
    "PATH": "__BIN__;${env:PATH}"
  }
}
'@
        Save '.vscode\settings.json' ($set.Replace('__BIN__', $binJ))
    }

    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

    # ---------- VS Code ----------
    Step "VS Code"
    $codeCmd = $null
    $c = Get-Command code -ErrorAction SilentlyContinue
    if ($c) { $codeCmd = $c.Source }
    else {
        foreach ($cand in @(
            (Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\bin\code.cmd'),
            (Join-Path $env:ProgramFiles 'Microsoft VS Code\bin\code.cmd'),
            (Join-Path ${env:ProgramFiles(x86)} 'Microsoft VS Code\bin\code.cmd'))) {
            if (Test-Path $cand) { $codeCmd = $cand; break }
        }
    }
    if ($codeCmd) {
        Write-Host "Installing C/C++ extension..."
        & $codeCmd --install-extension ms-vscode.cpptools --force | Out-Null
        Write-Host "Opening project in VS Code..."
        & $codeCmd $root (Join-Path $root 'src\main.cpp')
    } else {
        Write-Host "VS Code not found. Install it from https://code.visualstudio.com and open this folder:" -ForegroundColor Yellow
        Write-Host $root
        Write-Host "then install the 'C/C++' extension (Microsoft)."
    }

    Write-Host "`nDONE!  Ctrl+Shift+B = build,  F5 = run/debug." -ForegroundColor Green
}
catch {
    Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
}
